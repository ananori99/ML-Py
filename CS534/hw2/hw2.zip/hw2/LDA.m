%This is my work and I have not plagerized - Ana Noriega
function [f ,CovIn, mu1, mu2, p, CovMat] = LDA(X,Y)
%does LDA for a given set of data and responses
%   Input: the data and responses used for training
%assume data is given as two diffrent arrays, X the features and Y the
%results
%combinie these into a single array
allData = [X Y];
%Then seperate the data according to what class it belonged to
%This will only work for two classes!
%general: C = accumarray(X,1:size(M,1),[],@(r){M(r,:)});
C1 =  allData(allData(:,3)==0,:);
C2 =  allData(allData(:,3)==1,:);
%Then find the mean of each feature
mu1 = transpose(mean(C1(:,[1 2])));
mu2 = transpose(mean(C2(:,[1 2])));
globalMu = mean(X);
%use global mean to make the mean corrected data
centered1 = C1(:,[1 2])-globalMu;
centered2 = C2(:,[1 2])-globalMu;
%create the covarinces for each class, and then average / pool
Covfefe1 = cov(centered1);
Covfefe2 = cov(centered2);
%then the weighted average of the 
%the weights based on number of observations in each class
%this will be a problem for X's beyond how I constructed them
w1 = size(C1,1)/size(X,1);
w2 = size(C2,1)/size(X,1);
%then the pooled covariance is made
CovMat = w1.*Covfefe1 + w2.*Covfefe2;
CovIn = CovMat';
%prior probability, approximated by way # observations
p = [w1; w2];
%For the two discriminant functions, assign an observation to the one with
%the highest value
%here, for the sake of ploting return the function for the boundary
f=@(x1,x2)([x1,x2]*CovIn*mu1-0.5*transpose(mu1)*CovIn*mu1 +log10(p(1))-log10(p(2))+ 0.5*transpose(mu2)*CovIn*mu2 - [x1,x2]*CovIn*mu2);
